var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var hbs = require('hbs');
var cors = require('cors');
var passport = require('passport');

require('dotenv').config();

// MongoDB connector
require('./app_server/models/db');
require('./app_api/config/passport');

const apiRouter = require('./app_api/routes/index');
const indexRouter = require('./app_server/routes/index');
const errorHandler = require('./app_api/middleware/errorHandler'); //error handler added

var app = express();

app.use(cors({
  origin: 'http://localhost:4200',
  credentials: true
}));

// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// register handlebars partials
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

// routes
app.use('/api', apiRouter);
app.use('/', indexRouter);

// catch unauthorized error
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ message: err.name + ': ' + err.message });
  }
  next(err);
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  res.status(err.status || 500);

  if (req.originalUrl.startsWith('/api')) {
    res.json({
      message: err.message,
      error: err.status || 500
    });
  } else {
    res.render('error');
  }
});
app.use(errorHandler);
module.exports = app;