const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const validation = require('../middleware/validateTrip'); // validation of trip added
const jwt = require('jsonwebtoken'); // Enable JWT

// ==============================
// JWT Middleware
// ==============================
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    console.log('No Authorization Header');
    return res.sendStatus(401);
  }

  const token = authHeader.split(' ')[1];

  if (!token) {
    console.log('No Token Found');
    return res.sendStatus(401);
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      console.log('Invalid Token');
      return res.sendStatus(401);
    }

    req.auth = decoded;
    next();
  });
}

// ==============================
// AUTH ROUTES
// ==============================
router.post('/login', authController.login);
router.post('/register', authController.register);

// ==============================
// TRIP ROUTES
// ==============================

// Public (READ)
router.get('/trips', tripsController.tripsList);
router.get('/trips/:tripCode', tripsController.tripsFindCode);

// Protected (CRUD) // validation of trip added
router.post('/trips', authenticateJWT, validation.validateTrip, tripsController.tripsAddTrip);
router.put('/trips/:tripCode', authenticateJWT, validation.validateTrip, tripsController.tripsUpdateTrip);
router.delete('/trips/:tripCode', authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;