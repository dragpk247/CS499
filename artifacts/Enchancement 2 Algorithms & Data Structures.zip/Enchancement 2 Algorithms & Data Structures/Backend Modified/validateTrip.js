// validation of trip added
module.exports.validateTrip = (req, res, next) => {

    const {
        code,
        name,
        length,
        start,
        resort,
        perPerson,
        image,
        description
    } = req.body;

    // Validate required fields
    if (
        !code ||
        !name ||
        !length ||
        !start ||
        !resort ||
        !perPerson ||
        !image ||
        !description
    ) {
        return res.status(400).json({
            message: "All trip fields are required."
        });
    }

    // Validate trip length
    if (length <= 0) {
        return res.status(400).json({
            message: "Trip length must be greater than zero."
        });
    }

    // Validate trip price
    if (perPerson <= 0) {
        return res.status(400).json({
            message: "Trip price must be greater than zero."
        });
    }

    next();
};