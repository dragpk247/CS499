import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TripListComponent } from './components/trip-list/trip-list.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [

  { path: '', component: TripListComponent },

  { path: 'login', component: LoginComponent },

  { path: 'trips', component: TripListComponent },

  { path: '**', redirectTo: '' }

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { useHash: true })
  ],

  exports: [RouterModule]
})

export class AppRoutingModule { }