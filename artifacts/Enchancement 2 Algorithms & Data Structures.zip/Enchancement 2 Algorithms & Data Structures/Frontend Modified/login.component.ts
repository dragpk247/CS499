import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.component.html'
})

export class LoginComponent {

  credentials = {
    email: '',
    password: ''
  };

  errorMessage = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit(): void {

    if (
      !this.credentials.email ||
      !this.credentials.password
    ) {
      this.errorMessage = 'Please enter email and password.';
      return;
    }

    this.authService.login(this.credentials).subscribe({

      next: (response) => {

        this.authService.saveToken(response.token);

        this.router.navigate(['/admin']);
      },

      error: () => {

        this.errorMessage =
          'Login failed. Check email and password.';
      }
    });
  }
}