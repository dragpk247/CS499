import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { Trip } from '../../models/trip';
import { TripDataService } from '../../services/trip-data.service';

@Component({
  selector: 'app-trip-form',
  standalone: false,
  templateUrl: './trip-form.component.html',
  styleUrls: ['./trip-form.component.css']
})
export class TripFormComponent implements OnChanges {

  @Input() trip: Trip | null = null;

  @Output() saved = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();

  formTrip: Trip = this.emptyTrip();

  constructor(private tripDataService: TripDataService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.trip) {
      this.formTrip = { ...this.trip };
    } else {
      this.formTrip = this.emptyTrip();
    }
  }

  private emptyTrip(): Trip {
    return {
      code: '',
      name: '',
      length: '',
      start: '',
      resort: '',
      perPerson: '',
      image: '',
      description: ''
    };
  }

// frontend validation enhancement
onSubmit(): void {

  // Validate required fields
  if (
    !this.formTrip.code ||
    !this.formTrip.name ||
    !this.formTrip.length ||
    !this.formTrip.start ||
    !this.formTrip.resort ||
    !this.formTrip.perPerson ||
    !this.formTrip.image ||
    !this.formTrip.description
  ) {
    alert('All fields are required.');
    return;
  }

  // Validate trip length
  if (Number(this.formTrip.length) <= 0) {
    alert('Trip length must be greater than zero.');
    return;
  }

  // Validate price
  if (Number(this.formTrip.perPerson) <= 0) {
    alert('Trip price must be greater than zero.');
    return;
  }

  // Update existing trip
  if (this.trip) {

    this.tripDataService.updateTrip(this.formTrip).subscribe(() => {
      this.saved.emit();
    });

  } else {

    // Add new trip
    this.tripDataService.addTrip(this.formTrip).subscribe(() => {
      this.saved.emit();
    });
  }
}

  onCancel(): void {
    this.cancelled.emit();
  }
}