const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({

  code: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    uppercase: true
  },

  name: {
    type: String,
    required: true,
    trim: true,
    minlength: 3
  },

  length: {
    type: String,
    required: true,
    trim: true
  },

  start: {
    type: String,
    required: true,
    trim: true
  },

  resort: {
    type: String,
    required: true,
    trim: true
  },

  perPerson: {
    type: Number,
    required: true,
    min: 0
  },

  image: {
    type: String,
    required: true,
    trim: true
  },

  description: {
    type: String,
    required: true,
    trim: true,
    minlength: 20
  }

});

// ==========================================================
// CS499 DATABASE ENHANCEMENT
// Indexes added to improve search performance
// ==========================================================
tripSchema.index({ name: 1 });
tripSchema.index({ resort: 1 });

mongoose.model('trips', tripSchema);