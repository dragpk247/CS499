const mongoose = require('mongoose');
const Trip = mongoose.model('trips');


//   OLD CODE: 
// const tripsList = async (req, res) => {
//   try {
//     const trips = await Trip.find({});
//     res.status(200).json(trips);
//   } catch (err) {
//     res.status(500).json(err);
//   }
// };


// ==========================================================
// CS499 ALGORITHMS & DATA STRUCTURES ENHANCEMENT
// Pagination Algorithm
// Retrieves trip records in pages rather than returning
// the entire collection.
// ==========================================================

const tripsList = async (req, res) => {

  try {

    // pagination code

  } catch (err) {

    console.log('Trips list error:', err);

    return res.status(500).json({
      message: 'Unable to retrieve trips',
      error: err.message
    });

  }

};

// ==========================================================
// CS499 ALGORITHMS & DATA STRUCTURES ENHANCEMENT
// Search Algorithm
// Allows users to search trip records by trip name.
// ==========================================================
const searchTrips = async (req, res) => {

  try {

    const searchTerm = req.query.name || "";

    const trips = await Trip.find({
      name: {
        $regex: searchTerm,
        $options: "i"
      }
    });

    res.status(200).json(trips);

  } catch (err) {

    console.log('Search error:', err);

    return res.status(500).json({
      message: 'Search failed',
      error: err.message
    });

  }

};

// ==========================================================
// CS499 ALGORITHMS & DATA STRUCTURES ENHANCEMENT
// Sorting Algorithm
// Sorts trip collections by a selected field.
// ==========================================================
const sortTrips = async (req, res) => {

  try {

    const sortField = req.query.field || "name";

    const trips = await Trip
      .find({})
      .sort({
        [sortField]: 1
      });

    res.status(200).json(trips);

  } catch (err) {

    console.log('Sort error:', err);

    return res.status(500).json({
      message: 'Sort failed',
      error: err.message
    });

  }

};

const tripsFindCode = async (req, res) => {
  try {

    const trip = await Trip.findOne({
      code: req.params.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    res.status(200).json(trip);

  } catch (err) {

    console.log('Find trip error:', err);

    return res.status(500).json({
      message: 'Database Error',
      error: err.message
    });

  }
};

const tripsAddTrip = async (req, res) => {

  try {

    console.log('POST /api/trips body:', req.body);

    const trip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    res.status(201).json(trip);

  } catch (err) {

    console.log('Trip create error:', err);

    // Validation Error
    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: 'Validation failed',
        error: err.message
      });
    }

    // Duplicate Key Error
    if (err.code === 11000) {
      return res.status(409).json({
        message: 'Trip code already exists'
      });
    }

    return res.status(500).json({
      message: 'Database Error'
    });

  }
};

const tripsUpdateTrip = async (req, res) => {

  try {

    const trip = await Trip.findOne({
      code: req.params.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    trip.code = req.body.code;
    trip.name = req.body.name;
    trip.length = req.body.length;
    trip.start = req.body.start;
    trip.resort = req.body.resort;
    trip.perPerson = req.body.perPerson;
    trip.image = req.body.image;
    trip.description = req.body.description;

    const updatedTrip = await trip.save();

    res.status(200).json(updatedTrip);

  } catch (err) {

    console.log('Trip update error:', err);

    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: 'Validation failed',
        error: err.message
      });
    }

    if (err.code === 11000) {
      return res.status(409).json({
        message: 'Trip code already exists'
      });
    }

    return res.status(500).json({
      message: 'Database Error'
    });

  }
};

const tripsDeleteTrip = async (req, res) => {

  try {

    const deletedTrip = await Trip.findOneAndDelete({
      code: req.params.tripCode
    });

    if (!deletedTrip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    res.status(200).json({
      message: 'Trip deleted successfully'
    });

  } catch (err) {

    console.log('Trip delete error:', err);

    return res.status(500).json({
      message: 'Database Error',
      error: err.message
    });

  }
};

// updated exports
module.exports = {
  tripsList,
  tripsFindCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
  searchTrips,
  sortTrips
};